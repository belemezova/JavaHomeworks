package com.codix.bar;

public enum ProductType {
    DRINK,
    DISH
}
