package com.codix.bar;

import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;

public class Menu
{

  private List<Dish>    dishes = new ArrayList<>();
  private List<Product> drinks = new ArrayList<Product>();
  private String        name;

  private int id;

  public Menu()
  {

  }

  public void setDishes(List<Dish> dishes)
  {
    this.dishes = dishes;
  }

  public List<Product> getDrinks()
  {
    return drinks;
  }

  public List<Dish> getDishes()
  {
    return dishes;
  }

  @Override
  public String toString()
  {
    return "Menu{" +
        "dishes=" + dishes +
        ", drinks=" + drinks +
        ", name='" + name + '\'' +
        ", id=" + id +
        '}';
  }

  public void setDrinks(List<Product> drinks)
  {

    this.drinks = drinks;

  }


  public void setProducts(List<Dish> dishes)
  {
    this.dishes = dishes;
  }

  public String getName()
  {
    return name;
  }

  public void setName(String name)
  {
    this.name = name;
  }

  public int getId()
  {
    return id;
  }

  public void setId(int id)
  {
    this.id = id;
  }
}
