package com.codix.bar;

import java.math.BigDecimal;

public class Product {
    private int id;
    private String name;
    private BigDecimal price;
    private ProductType type;


    public Product(int id, String name, BigDecimal price, ProductType type) {
        this.id = id;
        this.name = name;
        this.price = price;
        this.type = type;

    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    @Override
    public String toString()
    {
        return

            "name = " + name +
            " price = " + price;


//        return "Product{" +
//            "id=" + id +
//            ", name='" + name + '\'' +
//            ", price=" + price +
//            ", type=" + type +
//            '}';
    }

    public void setName(String name) {
        this.name = name;
    }

    public BigDecimal getPrice() {
        return price;
    }

    public void setPrice(BigDecimal price) {
        this.price = price;
    }

    public ProductType getType() {
        return type;
    }

    public void setType(ProductType type) {
        this.type = type;
    }

}
