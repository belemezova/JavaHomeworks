package com.codix.bar;

import java.math.BigDecimal;
import java.util.LinkedHashMap;

public class Dish
{

  private String                          name;
  private String                          gramsOfDish;
  private BigDecimal                      price;
  private ProductType                     type;
  private LinkedHashMap<Product, Integer> recipe;

  @Override
  public String toString()
  {
    return "name = " + name +
        " gramsOfDish = " + gramsOfDish +
        " price = " + price;
//    return "Dish{" +
//        "name='" + name + '\'' +
//        ", gramsOfDish='" + gramsOfDish + '\'' +
//        ", price=" + price +
//        '}';
  }

  public Dish(String name, String gramsOfDish, BigDecimal price, ProductType type)
  {
    this.name = name;
    this.gramsOfDish = gramsOfDish;
    this.price = price;
    this.type = type;
  }

  public LinkedHashMap<Product, Integer> getRecipe()
  {
    return recipe;
  }

  public void setRecipe(LinkedHashMap<Product, Integer> recipe)
  {
    this.recipe = recipe;
  }

  public ProductType getType()
  {
    return type;
  }

  public void setType(ProductType type)
  {
    this.type = type;
  }

  public String getName()
  {
    return name;
  }

  public void setName(String name)
  {
    this.name = name;
  }

  public String getGramsOfDish()
  {
    return gramsOfDish;
  }

  public void setGramsOfDish(String gramsOfDish)
  {
    this.gramsOfDish = gramsOfDish;
  }

  public BigDecimal getPrice()
  {
    return price;
  }

  public void setPrice(BigDecimal price)
  {
    this.price = price;
  }
}
