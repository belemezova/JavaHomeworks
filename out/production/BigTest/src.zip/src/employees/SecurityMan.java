package employees;

import bar_Info_Tables_Booking.BookingSeats2;
import java.math.BigDecimal;
import methods.DayOfWeek;

public class SecurityMan extends Employee
{

  private BigDecimal wallet;

  public SecurityMan(String name, BigDecimal dailyWage)
  {
    super(name);
    this.setDailyWage(dailyWage);
    this.wallet=BigDecimal.ZERO;
  }

  public BigDecimal getWallet()
  {
    return wallet;
  }

  public void setWallet(BigDecimal wallet)
  {
    this.wallet = wallet;
  }



}
