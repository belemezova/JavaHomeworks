package employees;

public enum Band {
  SLAYER,
  SEPULTURA,
  BLOODBATH,
  BEHEMOTH,
  SYSTEM_OF_A_DOWN,
  SEPTIC_FLESH,
  SLIPKNOT,
  MESHUGGAH,
  JUDAS_PRIEST,
  LAMB_OF_GOD;
}
