package methods;

import employees.Band;
import employees.Employee;
import employees.TributeBand;
import java.awt.Image;
import java.awt.image.BufferedImage;
import java.util.ArrayList;
import javax.imageio.ImageIO;
import javax.swing.ImageIcon;
import javax.swing.JOptionPane;

public class DayOfWeek {

  private Staff staff;
  private TributeBand tributeBand;
  private String currentDay;
  private Band fridayBand;
  private Band saturdayBand;

  public DayOfWeek(Staff staff) {
    this.staff = staff;
    tributeBand = staff.getTributeBand();
  }

  public TributeBand getTributeBand() {
    return tributeBand;
  }

  public Band getFridayBand() {
    return fridayBand;
  }

  public void setFridayBand(Band fridayBand) {
    this.fridayBand = fridayBand;
  }

  public Band getSaturdayBand() {
    return saturdayBand;
  }

  public void setSaturdayBand(Band saturdayBand) {
    this.saturdayBand = saturdayBand;
  }

  public Staff getStaff() {
    return staff;
  }

  public String getCurrentDay() {
    return currentDay;
  }

  public void setDayOfWeek() {

    ArrayList<Band> bands = BandsForCurrentWeek.generateRandomBandsForTribute();
    fridayBand = bands.get(0);
    saturdayBand = bands.get(1);

    ArrayList<String> allOptionsForTheDay = new ArrayList<>();//create a list with all options for the week

    for (DaysOfWeek day : DaysOfWeek.values()) {

      if (day.equals(DaysOfWeek.MONDAY) || day.equals(DaysOfWeek.TUESDAY)) {
        continue;
      }

      if (day.equals(DaysOfWeek.FRIDAY)) {

        allOptionsForTheDay.add(day + " - " + fridayBand + " tribute - 10 lv entrance");
        continue;
      }
      if (day.equals(DaysOfWeek.SATURDAY)) {

        allOptionsForTheDay.add(
            day + " - " + saturdayBand + " tribute - 10 lv entrance");
        continue;
      }

      allOptionsForTheDay.add(day.toString());

    }

    ImageIcon callendarPhoto = new ImageIcon("src/photos/callendar_photo.jpg");

    try {
      String setDay = (String) JOptionPane.showInputDialog(//create dropdown menu for the day
          null,
          "Choose day, Monday and Tuesday is closed",
          "Day",
          JOptionPane.QUESTION_MESSAGE,
          callendarPhoto,
          allOptionsForTheDay.toArray(),
          allOptionsForTheDay.toArray()[0]);

      currentDay = setDay.split(" ")[0];
    } catch (NullPointerException ex) {
      System.out.println("You didn't choose a day!");
      return;
    }

    staff.getFirstWaiter().setOnShift(true);
    staff.getSecondWaiter().setOnShift(true);
    staff.getFirstBartender().setOnShift(true);
    staff.getSecondBartender().setOnShift(true);
    staff.getChef().setOnShift(true);

    if (currentDay.equals(DaysOfWeek.FRIDAY.toString()) || currentDay.equals(
        DaysOfWeek.SATURDAY.toString())) {

      staff.getSecurityMan().setOnShift(true);

      for (Employee bandMember : tributeBand.getBandMembers()) {

        bandMember.setOnShift(true);

      }
    }
  }

  public enum DaysOfWeek {
    MONDAY, TUESDAY, WEDNESDAY, THURSDAY, FRIDAY, SATURDAY, SUNDAY;
  }
}