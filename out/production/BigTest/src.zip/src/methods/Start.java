package methods;

import bar_Info_Tables_Booking.BarInfo;
import bar_Info_Tables_Booking.BarStartingCapital;
import bar_Info_Tables_Booking.BookingSeats2;
import bar_Info_Tables_Booking.ServicesMethods;
import com.codix.bar.Menu;
import com.codix.bar.Product;
import employees.Bartender;
import employees.Chef;
import employees.Employee;
import employees.SecurityMan;
import employees.TributeBand;
import employees.Waiter;
import java.util.ArrayList;
import java.util.List;
import methods.DayOfWeek.DaysOfWeek;
import test_data.CreateTestProducts;

public class Start {

  public static void runProgram() throws Exception {
    BarInfo barCheers = new BarInfo();
    Staff staff = new Staff();
    DayOfWeek day = new DayOfWeek(staff);
    day.setDayOfWeek();

    MusicPlayer musicPlayer = new MusicPlayer();
    checkForBandToday(day, musicPlayer);

    String today = day.getCurrentDay();
    System.out.print("The day you chose is " + today + "!");

    try {
      if (today.equals(DaysOfWeek.FRIDAY.toString())) {
        System.out.println(
            " " + staff.getTributeBand().getName() + " Will Play Tribute to "
                + day.getFridayBand());
      } else if (today.equals(DaysOfWeek.SATURDAY.toString())) {
        System.out.println(
            " " + staff.getTributeBand().getName() + " Will Play Tribute to "
                + day.getSaturdayBand());
      } else {
        System.out.println();
      }
    } catch (NullPointerException ex) {
      System.out.println("You didn't choose a day!");
      return;
    }
    System.out.println();


    ServicesMethods method = new ServicesMethods();
    method.printMenu();
    method.getBook().selectGuestsTable();
    System.out.println(method.getBook().getTaken());

    System.out.println();

    CreateTestProducts create = new CreateTestProducts();
    Menu menuDish = create.createDishMenu();
    // System.out.println(menuDish);
    Menu menuDrink = create.createDrinkMenu();
    //  System.out.println(menuDrink);
    /*LinkedHashMap<String, String[]> taken, List<Dish> listDishes, List<Product> listDrinks*/
    method.takingOrder(method.getBook().getTaken(), menuDish.getDishes(), menuDrink.getDrinks(),
        staff);
    method.prepareDrinks(method.getDrinks(), (Bartender) method.chooseStaff("Bartender", staff),
        create.getDrinkProducts(),
        method.getReadyOrders());

    System.out.println();
    System.out.println("Ready orders" + method.getReadyOrders().toString());
    method.prepareFood(method.getFood(), (Chef) staff.getChef(),
        create.getFoodProducts(), method.getReadyDish());

    System.out.println("Ready dishes" + method.getReadyDish().toString());
    System.out.println();

    System.out.println(method.calculateBill(staff));

    Employee securityMan = staff.getSecurityMan();
    BarStartingCapital startCapital = new BarStartingCapital();

    startCapital.setStartingMoney(startCapital.getStartingMoney().add(method.calculateBill(staff)));

    startCapital.collectTax(day, (SecurityMan) securityMan, method.getBook(),
        staff.getTributeBand());

//    ArrayList<Employee> employees = day
//        .getStaff()
//        .getEmployees();
//    TributeBand tributeBand = day
//        .getStaff()
//        .getTributeBand();

    System.out.println();

    for (Employee employee : staff.getEmployees()) {

      if (employee.isOnShift()) {

        if (employee instanceof Waiter) {
          System.out.println((Waiter) employee);

        } else if (employee instanceof Bartender){
          System.out.println((Bartender) employee);
        }else {
          System.out.println(employee);
        }
      }
      System.out.println();
      if (today.equals(DaysOfWeek.FRIDAY.toString())||today.equals(DaysOfWeek.SATURDAY.toString())){

          System.out.println(staff.getTributeBand().getBandMembers());

      }
    }

    MenuStatistic stats = new MenuStatistic();
    stats.ordersStats(method.getOrderedDishes(), menuDrink.getDrinks(), menuDish.getDishes(),
        method.getMenu());

    System.out.println("Most Ordered " + stats.getMostOrdered());
    System.out.println("Least Ordered " + stats.getLeastOrdered());

    method.printMenu();

    if (today.equals(DaysOfWeek.FRIDAY.toString()) || (today.equals(
        DaysOfWeek.SATURDAY.toString()))) {

      System.out.println("KEEP LISTENING!!!");
      Thread.sleep(1000000);
    }
  }

  private static void checkForBandToday(DayOfWeek day, MusicPlayer musicPlayer)
      throws NullPointerException {
    try {
      if (day
          .getCurrentDay()
          .equals(DaysOfWeek.FRIDAY.toString())) {

        String musicLocation = musicPlayer.musicLocation(day.getFridayBand());
        musicPlayer.turnTheMusic(musicLocation);
      }
      if (day
          .getCurrentDay()
          .equals(DaysOfWeek.SATURDAY.toString())) {

        String musicLocation = musicPlayer.musicLocation(day.getSaturdayBand());
        musicPlayer.turnTheMusic(musicLocation);
      }
    } catch (NullPointerException ex) {
      return;
    }
  }
}
