package methods;

import employees.Band;
import java.util.ArrayList;
import java.util.List;
import java.util.Random;

public class BandsForCurrentWeek {

  public static ArrayList<Band> generateRandomBandsForTribute() {
    Random random = new Random();

    int randomBandFridayIndex = random.nextInt(10);
    int randomBandSaturdayIndex = random.nextInt(10);

    while (randomBandFridayIndex == randomBandSaturdayIndex) {

      randomBandSaturdayIndex = random.nextInt(10);
    }

    Band fridayBand = Band.values()[randomBandFridayIndex];
    Band saturdayBand = Band.values()[randomBandSaturdayIndex];

    ArrayList<Band> bands = new ArrayList<>(List.of(fridayBand, saturdayBand));

    return bands;
  }
}
