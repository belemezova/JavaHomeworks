package methods;


import com.codix.bar.Dish;
import com.codix.bar.Drink;
import com.codix.bar.Product;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;

public class MenuStatistic {

  private List<String> mostOrdered;
  private List<String> leastOrdered;

  private HashMap<String, Integer> allOrders;

  private int minCount = Integer.MAX_VALUE;
  private int maxCount = Integer.MIN_VALUE;

  public MenuStatistic() {

    mostOrdered = new ArrayList<>();
    leastOrdered = new ArrayList<>();
    allOrders = new HashMap<>();
  }

  public HashMap<String, Integer> getAllOrders() {
    return allOrders;
  }

  public List<String> getMostOrdered() {
    return mostOrdered;
  }

  public List<String> getLeastOrdered() {
    return leastOrdered;
  }

  public void ordersStats(LinkedList<String[]> orders, List<Product> listDrinks,
      List<Dish> listDishes, ArrayList<Product> menuForPrint) {

    setAllOrders(orders,menuForPrint);//will added all ordered stuff with the count in allOrders

    setMinAndMax(menuForPrint);//set max and min count

    //These are the least ordered
    removeMinimums(listDrinks, listDishes, menuForPrint);

    //These are the most ordered
    for (Map.Entry<String, Integer> entry : allOrders.entrySet()) {

      if (entry.getValue() == maxCount) {
        mostOrdered.add(entry.getKey());
      }
    }


  }

  private void removeMinimums(List<Product> drinks, List<Dish> dishes,
      ArrayList<Product> menuForPrint) {
    ArrayList<String> toRemove = new ArrayList<>();

    for (Map.Entry<String, Integer> entry : allOrders.entrySet()) {

      String name = entry.getKey();
      int count = entry.getValue();

      if (count == minCount) {
        leastOrdered.add(name);
        toRemove.add(name);
      }
    }

    for (String currentProductToRemove : toRemove) {

      for (Product product : drinks) {

        if (product.getName().equals(currentProductToRemove)) {
          drinks.remove(product);
          break;
        }
      }

      for (Dish product : dishes) {

        if (product.getName().equals(currentProductToRemove)) {
          dishes.remove(product);
          break;
        }
      }

      for (Product product : menuForPrint) {

        if (product.getName().equals(currentProductToRemove)) {
          menuForPrint.remove(product);
          break;
        }
      }
    }
  }

  HashSet<String> names = new HashSet<>();

  private void setMinAndMax(ArrayList<Product> menuForPrint) {
    for (Map.Entry<String, Integer> entry : allOrders.entrySet()) {

      if (entry.getValue() < minCount) {
        minCount = entry.getValue();
      }
      if (entry.getValue() > maxCount) {
        maxCount = entry.getValue();
      }
      names.add(entry.getKey());
    }
    if (names.size() < menuForPrint.size()) {
      minCount = 0;
    }
  }

  private void setAllOrders(LinkedList<String[]> orders,ArrayList<Product>menuForPrint) {
    for (String[] currentRecord : orders) {

      String orderName = currentRecord[0];
      int orderCounter = Integer.parseInt(currentRecord[1]);

      if (allOrders.containsKey(orderName)) {

        for (Map.Entry<String, Integer> entry : allOrders.entrySet()) {

          allOrders.put(orderName, entry.getValue() + orderCounter);
          break;
        }
      } else {
        allOrders.put(orderName, 0);
      }
    }

    for (Product product:menuForPrint) {

      if (!allOrders.containsKey(product.getName())){
        allOrders.put(product.getName(), 0);

      }
    }
  }
}
