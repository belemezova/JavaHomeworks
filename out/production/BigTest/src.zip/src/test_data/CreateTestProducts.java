package test_data;

import com.codix.bar.*;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;

public class CreateTestProducts {

    private Product bun = new Product(6, "Bread", new BigDecimal(1), ProductType.DISH);
    private Product burgerMeat = new Product(11, "Meat", new BigDecimal(4), ProductType.DISH);
    private Product dough = new Product(12, "Dough", new BigDecimal(3), ProductType.DISH);
    private Product cheese = new Product(13, "Cheese", new BigDecimal(2), ProductType.DISH);
    private Product ham = new Product(14, "PizzaHam", new BigDecimal(1), ProductType.DISH);
    private Product potatoes = new Product(15, "Potatoes", new BigDecimal(3), ProductType.DISH);
    private Product water = new Product(16, "Water", new BigDecimal(1), ProductType.DRINK);
    private Product juice = new Product(17, "Juice", new BigDecimal(1), ProductType.DRINK);
    private Product cola = new Product(18, "Cola", new BigDecimal(2), ProductType.DRINK);
    private Product vodka = new Product(19, "Vodka", new BigDecimal(4), ProductType.DRINK);
    private Product whiskey = new Product(20, "Whiskey", new BigDecimal(4), ProductType.DRINK);
    private Product rum = new Product(21, "Rum", new BigDecimal(4), ProductType.DRINK);

    private Dish burger = new Dish("Burger", "350 grams", new BigDecimal(13), ProductType.DISH);
    private Dish pizza = new Dish("Pizza", "400 grams", new BigDecimal(10), ProductType.DISH);
    private Dish fries = new Dish("Fries", "200 grams", new BigDecimal(7), ProductType.DISH);
    private Dish friesWithCheese = new Dish("FriesWithCheese", "250 grams", new BigDecimal(8), ProductType.DISH);

    public Dish getBurger()
    {
        return burger;
    }

    public Dish getPizza()
    {
        return pizza;
    }

    public LinkedHashMap<Product, Integer> getFoodProducts()
    {
        return foodProducts;
    }

    public CreateTestProducts()
    {
        foodProducts = new LinkedHashMap<>();
        drinkProducts=new LinkedHashMap<>();
        createFoodStorage();
        createDrinkStorage();

    }

    public LinkedHashMap<Product, Integer> getDrinkProducts()
    {
        return drinkProducts;
    }

    public Dish getFries()
    {
        return fries;
    }

    public Dish getFriesWithCheese()
    {
        return friesWithCheese;
    }

    private LinkedHashMap<Product, Integer> foodProducts;
    private LinkedHashMap<Product, Integer> drinkProducts;

    public void createFoodStorage() {
        foodProducts.put(bun, 30);
        foodProducts.put(burgerMeat, 30);
        foodProducts.put(dough, 30);
        foodProducts.put(ham, 30);
        foodProducts.put(cheese, 50);
        foodProducts.put(potatoes, 40);
    }
    public void createDrinkStorage() {
        drinkProducts.put(water, 100);
        drinkProducts.put(juice, 100);
        drinkProducts.put(cola, 100);
        drinkProducts.put(vodka, 100);
        drinkProducts.put(whiskey, 100);
        drinkProducts.put(rum, 100);
    }

    public Menu createDishMenu() {
        LinkedHashMap<Product, Integer> burgerRecipe = new LinkedHashMap<>();
        burgerRecipe.put(bun, 1);
        burgerRecipe.put(burgerMeat, 1);
        burger.setRecipe(burgerRecipe);

        LinkedHashMap<Product, Integer> pizzaRecipe = new LinkedHashMap<>();
        pizzaRecipe.put(dough, 1);
        pizzaRecipe.put(ham, 1);
        pizzaRecipe.put(cheese, 1);
        pizza.setRecipe(pizzaRecipe);

        LinkedHashMap<Product, Integer> friesRecipe = new LinkedHashMap<>();
        friesRecipe.put(potatoes, 2);
        fries.setRecipe(friesRecipe);

        LinkedHashMap<Product, Integer> friesCheeseRecipe = new LinkedHashMap<>();
        friesCheeseRecipe.put(potatoes, 2);
        friesCheeseRecipe.put(cheese, 1);
        friesWithCheese.setRecipe(friesCheeseRecipe);

        List<Dish> listDishes = new ArrayList<>();
        listDishes.add(burger);
        listDishes.add(pizza);
        listDishes.add(fries);
        listDishes.add(friesWithCheese);

        Menu menu = new Menu();
        menu.setDishes(listDishes);
        menu.setId(1);
        menu.setName("dishMenu");
        return menu;
    }

    public Menu createDrinkMenu() {

        List<Product> listDrinks = new ArrayList<>();
        listDrinks.add(water);
        listDrinks.add(juice);
        listDrinks.add(cola);
        listDrinks.add(vodka);
        listDrinks.add(whiskey);
        listDrinks.add(rum);

        Menu menu1 = new Menu();
        menu1.setDrinks(listDrinks);
        menu1.setId(2);
        menu1.setName("drinkMenu");
        return menu1;
    }

    public List<Dish> filterProductsByType(List<Dish> dishes, ProductType type) {
        List<Dish> filteredProducts = new ArrayList<>();
        for (Dish currentDish : dishes) {
            if (currentDish.getType().equals(type)) {
                filteredProducts.add(currentDish);
            }
        }
        return filteredProducts;
    }
}


