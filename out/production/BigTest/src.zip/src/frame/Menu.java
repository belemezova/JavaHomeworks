package frame;

import java.awt.HeadlessException;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;

public class Menu extends JPanel
{


  private String[] optionsToChoose = {"Burger", "Pizza", "Fries", "FriesWithCheese", "Water", "Juice", "Cola",
      "Vodka",
      "Whiskey", "Rum"};



  public Menu() throws HeadlessException
  {
    JComboBox<String> jComboBox = new JComboBox<>(optionsToChoose);
    jComboBox.setBounds(80, 50, 140, 20);

    JButton jButton = new JButton("Done");
    jButton.setBounds(100, 100, 90, 20);

    JLabel jLabel = new JLabel();
    jLabel.setBounds(90, 100, 400, 100);

    this.add(jButton);
    this.add(jComboBox);
    this.add(jLabel);

    this.setLayout(null);
    this.setSize(350, 250);
    this.setVisible(true);

    jButton.addActionListener(new ActionListener()
    {
      @Override
      public void actionPerformed(ActionEvent e)
      {
        String selectedFruit = "You selected " + jComboBox.getItemAt(jComboBox.getSelectedIndex());
        jLabel.setText(selectedFruit);
      }
    });
  }


}

