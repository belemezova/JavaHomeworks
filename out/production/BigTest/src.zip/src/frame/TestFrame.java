package frame;

public class TestFrame
{

  public static void main(String[] args)
  {
    //new Password();
     new DashBoard("Dashboard");
  }
}
