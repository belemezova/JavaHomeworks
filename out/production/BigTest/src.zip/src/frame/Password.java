package frame;

import java.awt.BorderLayout;
import java.awt.Panel;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JPasswordField;
import javax.swing.border.Border;

public class Password extends JPasswordField
{

  final String password = "team5";
  JFrame         framePass = new JFrame();
  JPanel panel=new JPanel();
  JLabel label=new JLabel();


  JPasswordField pass;

  Password()
  {
    framePass.setSize(400,100);
    framePass.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
    framePass.setVisible(true);
    framePass.add(panel);
    pass = new JPasswordField(10);
    pass.setEchoChar('*');
    pass.addActionListener(new Al());
    label.setText("Enter password");
    panel.add(label, BorderLayout.WEST);
    panel.add(pass, BorderLayout.EAST);

  }
class Al implements ActionListener{

  @Override
  public void actionPerformed(ActionEvent e)
  {
    JPasswordField input=(JPasswordField)e.getSource();
    char[]passed= input.getPassword();
    String p= new String (passed);
    if(p.equals(password)){
      JOptionPane.showMessageDialog(null, "Correct");
    }else {
      JOptionPane.showMessageDialog(null, "Incorrect");
    }
  }
}
}