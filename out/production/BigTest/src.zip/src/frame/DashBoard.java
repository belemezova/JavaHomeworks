package frame;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.GridBagConstraints;

import java.awt.HeadlessException;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JButton;

import javax.swing.JDialog;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JPasswordField;

public class DashBoard extends JDialog implements ActionListener
{


  JButton button;
  JLabel  label;

  final String password="team5";
  JPasswordField pass;
  DashBoard(String dashboard)
  {
    this.setDefaultCloseOperation(JDialog.DO_NOTHING_ON_CLOSE);
    this.setLayout(new BorderLayout(10,10));
    this.setSize(500, 500);
    this.setTitle(dashboard);
    this.setFont(new Font("Comic Sans", Font.BOLD, 25));
    JPanel panel1=new JPanel();
    JPanel panel2=new JPanel();
    JPanel panel3=new JPanel();


    JLabel label= new JLabel();

    panel1.setBackground(Color.LIGHT_GRAY);
    panel2.setBackground(Color.GRAY);
    panel3.setBackground(Color.LIGHT_GRAY);

    panel1.setPreferredSize(new Dimension(100,50));
    panel2.setPreferredSize(new Dimension(100,100));
    panel3.setPreferredSize(new Dimension(100,100));

    this.add(panel1,BorderLayout.NORTH );
    this.add(panel2,BorderLayout.WEST );
    this.add(panel3,BorderLayout.CENTER);
    label.setText("Bar_Cheers");
    label.getHorizontalTextPosition();
    setFont(new Font("Comic Sans", Font.BOLD, 25));
    panel1.add(label);
    panel2.add(new Menu());// throws HeadlessException)
    label.setVisible(true);

    this.setVisible(true);

  }


    @Override
    public void actionPerformed(ActionEvent e)
    {
      String butSrcTxt = e.getActionCommand();
    }

}
