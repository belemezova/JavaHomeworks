package bar_Info_Tables_Booking;

public class BarInfo
{

  public final static String      BAR_NAME = "Bar NewHope";
  public final static String      Address  = "бул. „Княз Александър Дондуков 14,  1000 София център, София";
  public final static String      website  = "www.BarNewHope.bg";
  public final static String      phone    = "35929243377";
  public              boolean     isOpen;
  public static String            workingHours;


  public BarInfo()
  {
    setWorkingHours("19:00 PM- 1:00 AM");
    isOpen=true;
  }

  public boolean isOpen()
  {
    return isOpen;
  }

  public void setOpen(String day, int hour, String amOrPm)
  {if(hour >= 19 && amOrPm.equals("PM") || hour <= 1 && amOrPm.equals("AM") && !day.equals("MONDAY") || !day.equals("TUESDAY")){
    isOpen = true;
  }else {isOpen=false;}

  }

  public static String getWorkingHours()
  {
    return workingHours;
  }

  public static void setWorkingHours(String workingHours)
  {
    BarInfo.workingHours = workingHours;
  }


}
