package bar_Info_Tables_Booking;


import java.util.LinkedHashMap;
import java.util.LinkedList;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Random;


public class BookingSeats2
{//singleton

  public static Random ran = new Random();


  private LinkedHashMap<String, String[]> taken;

  private LinkedHashMap<String, String[]> availableSeats;
  private LinkedList<Integer>             queueGuest;

  private LinkedHashMap<String, String[]> allSeats;
  private Seats                           seats;


  private int     standings;
  private int     person;
  private int     takenSeats          = 0;
  private boolean vacateSeatsIsCalled = false;
  private int     guestsToBeHosted;

  public int getPerson()
  {
    return person;
  }

  public LinkedHashMap<String, String[]> getTaken()
  {
    return taken;
  }

  public LinkedHashMap<String, String[]> getAvailableSeats()
  {
    return availableSeats;
  }

  public LinkedHashMap<String, String[]> getAllSeats()
  {
    return allSeats;
  }

  public boolean isVacateSeatsIsCalled()
  {
    return vacateSeatsIsCalled;
  }

  public int getGuestsToBeHosted()
  {

    return guestsToBeHosted;
  }

  private int freeSeats = 40;

  public int getStandings()
  {
    return standings;
  }

  public int getTakenSeats()
  {
    return takenSeats;
  }

  public int getFreeSeats()
  {
    return freeSeats;
  }


  public void setStandings()
  {
    this.standings = 10;
  }

  public void setVacateSeatsIsCalled(boolean vacateSeatsIsCalled)
  {
    this.vacateSeatsIsCalled = vacateSeatsIsCalled;
  }

  public void setGuestsToBeHosted(int guestsToBeHosted)
  {
    this.guestsToBeHosted = guestsToBeHosted;
  }

  public void setFreeSeats(int freeSeats)
  {
    this.freeSeats = freeSeats;
  }

  @Override
  public String toString()
  {
    return "BookingSeats2{" +
        "availableSeats=" + availableSeats +
        ", queueGuest=" + queueGuest +
        ", allSeats=" + allSeats +
        ", guestPerDay=" + person +
        '}';
  }

  public BookingSeats2()
  {

    this.allSeats = setAllSeats();
    this.availableSeats = availableSeats();
    guestsToBeHosted = ran.nextInt(22 - 5) + 5;
    // this.queueGuest = hostFirstGroupGuests();
    this.taken = new LinkedHashMap<>();
  }

/*  public LinkedList<Integer> hostFirstGroupGuests()
  {
    guestsToBeHosted = 0;
    LinkedList<Integer> queueGuest = new LinkedList<>();

    int person = 0;
    while (guestPerDay > 0) {
      person = ran.nextInt(6 - 1) + 1;
      if (guestPerDay - person > 0) {

        queueGuest.add(person);
        guestPerDay -= person;
      }
      else {
        queueGuest.add(guestPerDay);
        break;
      }


    }
    return queueGuest;
  }*/

  public void removeFromBooking(LinkedHashMap<String, String[]> taken)
  {

    if (taken.size() > 0) {
      for (Map.Entry<String, String[]> takenEntry : taken.entrySet()) {
        if ((takenEntry.getValue().length > 0) && ((takenEntry.getValue()[1]).equals(
            IsAble.ENABLE.name()))) {
          taken.remove(takenEntry.getKey());
        }
      }
    }
  }

/*  public LinkedHashMap<String, String[]> hostGuestTakenSeat()
  {
    taken = new LinkedHashMap<>();
    int k = queueGuest.size();
    for (int i = 0; i < k; i++) {
      if (!queueGuest.isEmpty()) {
        int num = queueGuest.get(i);
        selectGuestsTable(num);
        System.out.println( num);
        queueGuest.remove(i);
        k--;
      }else {
        break;
      }

    }
    return taken;
  }*/

  public void selectGuestsTable()
  {
    for (int i = 0; i < guestsToBeHosted; i++) {
      int person = ran.nextInt(6 - 1) + 1;

      boolean stillPersonsToAdd = true;
      if (availableSeats.containsKey(getKey(availableSeats, person))) {
        String key = getKey(availableSeats, person);
        taken.put(key, new String[]{"" + (person), IsAble.DISABLE.toString()});
        availableSeats.replace(key, new String[]{String.valueOf(person), IsAble.ENABLE.toString()},
            new String[]{"" + (person),
                IsAble.DISABLE.toString()});
        takenSeats += person;
        freeSeats -= takenSeats;
        stillPersonsToAdd = false;
      }

      while (stillPersonsToAdd) {
        int diff = 0;
        if (availableSeats.containsKey(getKey(availableSeats, person))) {
          diff = person;
          String key = getKey(availableSeats, person);
          taken.put(key, new String[]{String.valueOf(person), IsAble.DISABLE.toString()});
          availableSeats.replace(key, new String[]{String.valueOf(person), IsAble.ENABLE.toString()},
              new String[]{"" + (person),
                  IsAble.DISABLE.toString()});
          takenSeats += person;
          freeSeats -= takenSeats;
          stillPersonsToAdd = false;
        }
        else {
          for (Entry<String, String[]> entry : availableSeats.entrySet()) {
            String k = entry.getKey();
            Integer v = Integer.valueOf(entry.getValue()[0]);
            String status = entry.getValue()[1];
            if (availableSeats.containsKey(getKey(availableSeats, person))) {
              diff = person;
            }
            if (Math.abs(person - v) <= 2) {

              if (person - v > 0) {
                diff = v;
              }
              else {
                diff = person;
              }
              taken.put(k, new String[]{String.valueOf(diff), IsAble.DISABLE.toString()});
              entry.getValue()[1] = IsAble.DISABLE.toString();
              takenSeats += diff;
              freeSeats -= takenSeats;
              person = person - diff;
              if (person <= 0) {
                stillPersonsToAdd = false;
              }
            }
            if (stillPersonsToAdd == false) {
              break;
            }
          }
        }
      }
      guestsToBeHosted -= person;
    }
  }

/*
    guestsToBeHosted = ran.nextInt(8 - 2) + 2;

    boolean stillPersonsToAdd = true;

    while (guestsToBeHosted != 0) {

      switch (guestsToBeHosted) {

        case 1:
          for (int i = 1; i <= 8; i++) {
            if ((availableSeats.get("BAR_CH" + i))[1].equals(
                IsAble.ENABLE.name())) {
              guestsToBeHosted = puttingCase(1, guestsToBeHosted, stillPersonsToAdd);
            }
          }
          break;
        case 2:
          if ((availableSeats.get("T8"))[1].equals(IsAble.ENABLE.name())) {
            setTakenSeats(2, "T8", stillPersonsToAdd);
            guestsToBeHosted = puttingCase(2, guestsToBeHosted, stillPersonsToAdd);

          }

          else if ((availableSeats.get("T9"))[1].equals(
              IsAble.ENABLE.name())) {
            setTakenSeats(2, "T9", stillPersonsToAdd);
            guestsToBeHosted = puttingCase(2, guestsToBeHosted, stillPersonsToAdd);
          }
          break;
        case 3:
        case 4:
          if ((availableSeats.get("T2"))[1].equals(IsAble.ENABLE.name())) {
            setTakenSeats(guestsToBeHosted, "T2", stillPersonsToAdd);
            guestsToBeHosted = puttingCase(guestsToBeHosted, guestsToBeHosted, stillPersonsToAdd);
          }
          else if ((availableSeats.get("T3"))[1].equals(
              IsAble.ENABLE.name())) {
            setTakenSeats(guestsToBeHosted, "T3", stillPersonsToAdd);
            guestsToBeHosted = puttingCase(guestsToBeHosted, guestsToBeHosted, stillPersonsToAdd);
          }
          else if ((availableSeats.get("T4"))[1].equals(
              IsAble.ENABLE.name())) {
            setTakenSeats(guestsToBeHosted, "T3", stillPersonsToAdd);
            guestsToBeHosted = puttingCase(guestsToBeHosted, guestsToBeHosted, stillPersonsToAdd);
          }
          else if ((availableSeats.get("T3"))[1].equals(
              IsAble.ENABLE.name())) {
            setTakenSeats(guestsToBeHosted, "T5", stillPersonsToAdd);
            guestsToBeHosted = puttingCase(guestsToBeHosted, guestsToBeHosted, stillPersonsToAdd);
          }
          else if ((availableSeats.get("T6"))[1].equals(
              IsAble.ENABLE.name())) {
            setTakenSeats(guestsToBeHosted, "T6", stillPersonsToAdd);
            guestsToBeHosted = puttingCase(guestsToBeHosted, guestsToBeHosted, stillPersonsToAdd);
          }
          break;

        case 6:
          if ((availableSeats.get("T1"))[1].equals(
              IsAble.ENABLE.name())) {
            int diff = 0;
            if (guestsToBeHosted > 6) {
              diff = 6;
            }
            else {
              diff = guestsToBeHosted;
            }
            setTakenSeats(diff, "T1", stillPersonsToAdd);
            guestsToBeHosted = puttingCase(diff, guestsToBeHosted, stillPersonsToAdd);
          }
          else {
            break;
          }

        default:

          if (stillPersonsToAdd) {
            guestsToBeHosted = guestsToBeHosted;
          }
          break;
      }
    }
  }*/

  public int puttingCase(int times, int person, boolean stillPersonsToAdd)
  {
    person -= times;
    if (person == 0) {
      stillPersonsToAdd = false;
    }
    return person;

  }

  public void setTakenSeats(int person, String key, boolean stillPersonsToAdd)
  {
    taken.put(key, new String[]{String.valueOf(person).trim(), IsAble.DISABLE.toString()});
    String[] value = availableSeats.get(key);
    String[] temp = new String[2];
    temp[0] = String.valueOf(0);
    temp[1] = IsAble.DISABLE.name();
    availableSeats.replace(key, temp);
    takenSeats += person;
    freeSeats -= takenSeats;
    if (person == 0) {
      stillPersonsToAdd = false;
    }
  }

 /* public void hostLastGuests()
  {
    if (guestsToBeHosted != 0 && vacateSeatsIsCalled) {
      selectGuestsTable(guestsToBeHosted);
    }
  }*/

  public void vacateSeats(LinkedHashMap<String, String[]> taken,
      LinkedHashMap<String, String[]> availableSeats, String tableSeat)
  {
    if (taken.containsKey(tableSeat)) {
      taken.get(tableSeat)[1] = IsAble.ENABLE.name();
      availableSeats.get(tableSeat)[1] = IsAble.ENABLE.name();
      taken.remove(tableSeat);
      takenSeats -= Integer.valueOf(taken.get(tableSeat)[0]);
      freeSeats += Integer.valueOf(taken.get(tableSeat)[0]);
      vacateSeatsIsCalled = true;
    }
  }

  public void changeNumberOfTakenSeats(Integer number, String table,
      LinkedHashMap<String, String[]> taken)
  {
    String[] value = taken.get(table);
    value[1] = number.toString();
    taken.replace(table, taken.get(table), value);
  }

  public void changeOneAvailableTableWithAnother(String oldNameTable, String newNameTable,
      LinkedHashMap<String,
          String[]> availableSeats, LinkedHashMap<String, String[]> allSeats)
  {
    if (availableSeats.containsKey(oldNameTable)) {
      availableSeats.remove(oldNameTable);
    }
    if (allSeats.containsKey(newNameTable)) {
      availableSeats.put(newNameTable, allSeats.get(newNameTable));
    }
  }

  public String getKey(LinkedHashMap<String, String[]> availableSeats, Integer value)
  {
    String key = " ";
    for (Entry<String, String[]> entry : availableSeats.entrySet()) {
      if (value.equals(Integer.parseInt(entry.getValue()[0]))) {
        key = entry.getKey();
        break;
      }
    }
    return key;
  }

  public int checkCapacity(LinkedHashMap<String, String[]> availableSeats)
  {
    availableSeats();
    int sum = 0;
    for (Entry<String, String[]> entry : availableSeats.entrySet()) {
      int v = Integer.valueOf(entry.getValue()[0]);
      sum += v;
    }
    return sum;
  }

  public LinkedHashMap<String, String[]> availableSeats()
  {
    for (Entry<String, String[]> entry : availableSeats.entrySet()) {
      if (entry.getValue()[1].equals(IsAble.DISABLE.toString())) {
        availableSeats.remove(entry);
      }
    }
    return availableSeats;
  }

  public LinkedHashMap<String, String[]> setAllSeats()
  {
    LinkedHashMap<String, String[]> allSeats = new LinkedHashMap<>();
    for (Seats s : Seats.values()) {
      allSeats.put(s.getName(), new String[]{("" + s.getCapacity()),
          IsAble.ENABLE.toString()});
    }
    availableSeats = allSeats;
    this.allSeats = allSeats;
    return allSeats;
  }
}

// Unbooking
