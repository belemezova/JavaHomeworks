package bar_Info_Tables_Booking;

import employees.Employee;
import employees.SecurityMan;
import employees.TributeBand;
import java.math.RoundingMode;
import methods.DayOfWeek;

import java.math.BigDecimal;

public class BarStartingCapital
{

  private BigDecimal startingMoney;

  public BarStartingCapital()
  {
    this.startingMoney = new BigDecimal(1000);
  }

  public void setStartingMoney(BigDecimal startingMoney)
  {

    this.startingMoney = startingMoney;
  }

  public BigDecimal getStartingMoney()
  {
    return startingMoney;
  }

  @Override
  public String toString()
  {
    return "BarStartingCapital{}";
  }

  public void collectTax(DayOfWeek day, SecurityMan securityMan, BookingSeats2 bookingSeats2,
      TributeBand tributeBand)
  {
    System.out.println(bookingSeats2.getTakenSeats());
    if (day.equals(DayOfWeek.DaysOfWeek.FRIDAY) || day.equals(DayOfWeek.DaysOfWeek.SATURDAY)) {
      BigDecimal MoneyFromEntryTax = new BigDecimal(bookingSeats2.getTakenSeats() * 10);
      securityMan.setWallet(MoneyFromEntryTax);
    }
    BigDecimal halfMoneyFromEntryTaxes = securityMan
        .getWallet()
        .divide(new BigDecimal(2), RoundingMode.HALF_UP);
    tributeBand.setBandHonorarium(halfMoneyFromEntryTaxes);
    securityMan.setWallet(halfMoneyFromEntryTaxes);

    BigDecimal wagePerPersonOfBand = halfMoneyFromEntryTaxes
        .divide(new BigDecimal(tributeBand
            .getBandMembers()
            .size()),RoundingMode.HALF_UP);
    tributeBand.setBandHonorarium(halfMoneyFromEntryTaxes);
    for (Employee emp:tributeBand.getBandMembers())
    {
      emp.setDailyWage(wagePerPersonOfBand);
    }
  }

}
