package bar_Info_Tables_Booking;

import java.math.BigDecimal;

public class BarTurnover {
    private BigDecimal turnover;

    public BarTurnover() {

    }

    public BigDecimal getTurnover() {
        return turnover;
    }

    public void setTurnover(BigDecimal turnover) {
        this.turnover = turnover;
        //turnover = money from orders + money from SecurityMan (if it is Friday or Saturday)
    }
}

