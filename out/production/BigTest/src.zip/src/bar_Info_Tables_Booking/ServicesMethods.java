package bar_Info_Tables_Booking;


import com.codix.bar.Dish;
import com.codix.bar.Product;
import com.codix.bar.ProductType;
import employees.Bartender;
import employees.Chef;
import employees.Employee;
import employees.Waiter;
import java.math.BigDecimal;
import java.math.RoundingMode;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Random;
import java.util.concurrent.ArrayBlockingQueue;
import java.util.stream.Collectors;
import methods.Staff;


public class ServicesMethods
{

  private static Random ran = new Random();

  private ArrayList<Product> menu;

  private LinkedHashMap<String, Order>   allOrders;
  private ArrayBlockingQueue<Product>    drinks;
  private LinkedHashMap<String, Integer> numberOfOrdersOnTable;
  private ArrayBlockingQueue<Dish>       food;

  public void setReadyOrders(ArrayBlockingQueue<Product> readyOrders)
  {
    this.readyOrders = readyOrders;
  }

  public ArrayBlockingQueue<Dish> getReadyDish()
  {
    return readyDish;
  }

  public void setReadyDish(ArrayBlockingQueue<Dish> readyDish)
  {
    this.readyDish = readyDish;
  }

  private ArrayBlockingQueue<Product> readyOrders = new ArrayBlockingQueue<>(50);
  private ArrayBlockingQueue<Dish>    readyDish   = new ArrayBlockingQueue<>(50);
  private LinkedList<String[]>        orderedDishes;


  public LinkedHashMap<String, Integer> getNumberOfOrdersOnTable()
  {
    return numberOfOrdersOnTable;
  }

  public LinkedHashMap<String, Order> getAllOrders()
  {
    return allOrders;
  }

  public ArrayBlockingQueue<Product> getDrinks()
  {
    return drinks;
  }

  public ArrayBlockingQueue<Dish> getFood()
  {
    return food;
  }

  public LinkedList<String[]> getOrderedDishes()
  {
    return orderedDishes;
  }

  private BookingSeats2 book;


  public ArrayList<Product> getMenu()
  {
    return menu;
  }

  public BookingSeats2 getBook()
  {
    return book;
  }

  public ServicesMethods()
  {
    this.book = new BookingSeats2();
    this.menu = setMenuList();
    this.allOrders = new LinkedHashMap<>();
    this.drinks = new ArrayBlockingQueue<>(50);
    this.food = new ArrayBlockingQueue<>(50);
    this.orderedDishes = new LinkedList<>();
    this.numberOfOrdersOnTable = new LinkedHashMap<>();

  }


  public ArrayBlockingQueue<Product> getReadyOrders()
  {
    return readyOrders;
  }

  public Employee chooseStaff(String signatureOfEmployee, Staff staff)
  {
    int firstOrSecond = ran.nextInt(2) + 1;
    if (signatureOfEmployee.contains("Waiter")) {
      if (firstOrSecond == 1) {
        return staff.getFirstWaiter();
      }
      else {
        return staff.getFirstBartender();
      }
    }
    else {
      if (firstOrSecond == 1) {
        return staff.getFirstBartender();
      }
      else {
        return staff.getSecondBartender();
      }
    }


  }

  public void takingOrder(LinkedHashMap<String, String[]> taken, List<Dish> listDishes, List<Product> listDrinks,
      Staff staff)

  {
    for (Entry<String, String[]> entry : taken.entrySet()) {
      String seatName = entry.getKey();
      System.out.println(seatName);
      // String[] value = entry.getValue();
      int maxItemsToOrder = 3;//(Integer.parseInt(entry.getValue()[0].trim())) * (ran.nextInt(3 - 1) + 1);
      if (seatName
          .startsWith("T")) {
        String staffName = chooseStaff("Waiter", staff).getName();
        puttingInOrderList(seatName, staffName, maxItemsToOrder, taken, listDishes,
            listDrinks);
      }

      else {
        String staffName = chooseStaff("Bartender", staff).getName();
        puttingInOrderList(seatName, staffName, maxItemsToOrder, taken, listDishes,
            listDrinks);
      }
    }
  }


  public String getTableForDeliverPreparedFromOrder(ArrayBlockingQueue<Product> prepared,
      LinkedHashMap<String, Integer> numberOfOrdersOnTable)
  {
    int sum = 0;
    String key = "";
    for (Entry<String, Integer> entry : numberOfOrdersOnTable.entrySet()) {
      sum += entry.getValue();
      if (sum >= prepared.size()) {
        key = entry.getKey();
        break;
      }
    }
    return key;
  }

  public String seatNameOfDelivery(String getTableForDeliverPreparedFromOrder,
      LinkedHashMap<String, Order> allOrders)
  {
    String seatName = allOrders
        .get(getTableForDeliverPreparedFromOrder)
        .getNameSeat();
    return seatName;
  }

  public LinkedHashMap<String, List<String[]>> listWithOrders(LinkedHashMap<String, Order> allOrders)
  {
    LinkedHashMap<String, List<String[]>> listWithOrders = new LinkedHashMap<>();
    for (Entry<String, Order> entry : allOrders.entrySet()) {
      listWithOrders.put(entry.getKey(), entry
          .getValue()
          .getOrderedDishes());
    }
    return listWithOrders;
  }

  public void puttingInOrderList(String seatName, String staffName, int maxItemsToOrder,
      LinkedHashMap<String, String[]> taken, List<Dish> listDishes, List<Product> listDrinks)
  {
    Order order = new Order();
    for (int i = 1; i <= maxItemsToOrder; i++) {
      int productName = ran.nextInt(9) + 1;
      int quantity = ran.nextInt(3 - 1) + 1;
      String generatedMenuItem = getProductName(getMenu(), productName);
      System.out.println(generatedMenuItem);
      orderedDishes.add(new String[]{generatedMenuItem, String.valueOf(quantity),});
      if (listDrinks
          .stream()
          .filter(o -> o
              .getName()
              .equals(generatedMenuItem))
          .collect(Collectors.toList())
          .size() > 0) {

        puttingInDrinkListForBartender(generatedMenuItem, listDrinks, quantity, drinks);

      }
      else if (listDishes
          .stream()
          .filter(o -> o
              .getName()
              .equals(generatedMenuItem))
          .collect(Collectors.toList())
          .size() > 0) {

        puttingInFoodListForCooker(generatedMenuItem, quantity, listDishes, food);
      }

    }

    order.setOrderedDishes(orderedDishes);
    order.setNameSeat(seatName);
    order.setMaxItemsToOrder(maxItemsToOrder);
    order.setNameEmployee(staffName);
    order.setStatus(IsActive.ACTIVE);
    order.setPersons(Integer.parseInt((taken.get(seatName)[0]).trim()));
    order.setNameEmployee(staffName);
    allOrders.put(seatName, order);

  }


  private void puttingInDrinkListForBartender(String productName, List<Product> listDrinks, int quantity,
      ArrayBlockingQueue<Product> drinks)
  {
    for (int i = 1; i <= quantity; i++) {
      Product drink = listDrinks
          .stream()
          .filter(o -> o
              .getName()
              .equals(productName))
          .collect(Collectors.toList())
          .get(0);
      drinks.offer(drink);
    }


  }

  public void puttingInFoodListForCooker(String productName, int quantity, List<Dish> listDishes,
      ArrayBlockingQueue<Dish> food)
  {
    for (int i = 1; i <= quantity; i++) {
      Dish dish = listDishes
          .stream()
          .filter(o -> o
              .getName()
              .equals(productName))
          .collect(Collectors.toList())
          .get(0);
      food.offer(dish);
    }
  }

  public BigDecimal calculateBill(Staff staff)
  {
    BigDecimal sum = new BigDecimal(0);

    for (Entry<String, Order> entry : allOrders.entrySet()) {
      Order order1 = entry.getValue();
      BigDecimal sumOfSingleOrder = new BigDecimal(0);
      LinkedList<String[]> nameDishes = order1.getOrderedDishes();
      for (String[] s : nameDishes) {
        String nameOfOrderProducts = s[0];
        BigDecimal price = getPrice(nameOfOrderProducts);

        BigDecimal amount = price.multiply(BigDecimal.valueOf(Integer.parseInt(s[1])));

        sumOfSingleOrder = sumOfSingleOrder.add(amount);
      }
      System.out.println(order1 + "\n" + sum.add(sumOfSingleOrder));
      for (Employee employee : staff.getEmployees()) {
        if (employee
            .getName()
            .equals(order1.getNameEmployee()) && employee instanceof Waiter) {
          ((Waiter) employee).setTip(sum
              .add(sumOfSingleOrder)
              .divide(BigDecimal.TEN, RoundingMode.HALF_UP));
          System.out.println("Tip Waiter " + ((Waiter) employee).getTip());
        }
        if (employee
            .getName()
            .equals(order1.getNameEmployee()) && employee instanceof Bartender) {
          ((Bartender) employee).setTip(sum
              .add(sumOfSingleOrder)
              .divide(BigDecimal.TEN, RoundingMode.HALF_UP));
          System.out.println("Tip Bartender " + ((Bartender) employee).getTip());
        }
      }

      sum = sum.add(sum.add(sumOfSingleOrder));
    }
    return sum;
  }

  public LinkedHashMap<String, Integer> numberOfOrdersOnTable(LinkedHashMap<String, Order> allOrders,
      LinkedHashMap<String, Integer> numberOfOrdersOnTable)
  {

    for (Entry<String, Order> entry : allOrders.entrySet()) {
      numberOfOrdersOnTable.put(entry.getKey(), entry
          .getValue()
          .getMaxItemsToOrder());
    }
    return numberOfOrdersOnTable;
  }
  // food.addAll(Collections.nCopies(quantity, menu.get(productID)));-throwing an exception after adding only some
  // of the elements in c

  public void deleteDishOrDrinkFromOrderedList(String tableOrSeatName, String productName)
  {
    Order fromTobeRemoved = allOrders.get(tableOrSeatName);
    LinkedList<String[]> orderedproducts = fromTobeRemoved.getOrderedDishes();
    int index = orderedproducts.indexOf(productName);
    int quantity = 0;
    if (!(index == -1)) {
      quantity = Integer.parseInt(orderedproducts.get(index)[1]) - 1;
    }
    orderedproducts.set(index, new String[]{productName, String.valueOf(quantity)});
  }

  public void deleteDishFromPreparingQueue(ArrayBlockingQueue<Product> food, String productName)
  {

    Product[] array = (Product[]) food.toArray();
    for (int i = 0; i < array.length; i++) {
      if (array[i]
          .getName()
          .equals(productName)) {
        food.remove(array[i]);
      }
    }
  }

  public Integer getProductID(ArrayList<Product> menu, String productName)
  {
    Integer productID = 0;
    for (int i = 0; i < menu.size(); i++) {
      if (menu
          .get(i)
          .getName()
          .equals(productName)) {
        productID = menu
            .get(i)
            .getId();
      }
    }
    return productID;
  }

  public String getProductName(ArrayList<Product> menu, Integer productID)
  {
    String productName = "";
    for (int i = 0; i < menu.size(); i++) {
      if (menu
          .get(i)
          .getId()
          == (productID)) {
        productName = menu
            .get(i)
            .getName();
        break;
      }
    }
    return productName;
  }

  public BigDecimal getPrice(String name)
  {
    for (int i = 0; i < menu.size(); i++) {
      if (menu
          .get(i)
          .getName()
          .equals(name)) {
        return menu
            .get(i)
            .getPrice();
      }
    }
    return BigDecimal.ONE;
  }

  public ArrayList<Product> setMenuList()
  {
    Product burger = new Product(1, "Burger", new BigDecimal(13), ProductType.DISH);
    Product pizza = new Product(2, "Pizza", new BigDecimal(10), ProductType.DISH);
    Product fries = new Product(3, "Fries", new BigDecimal(7), ProductType.DISH);
    Product friesWithCheese = new Product(4, "FriesAndCheese", new BigDecimal(8), ProductType.DISH);
    Product water = new Product(5, "Water", new BigDecimal(2), ProductType.DRINK);
    Product juice = new Product(6, "Juice", new BigDecimal(1), ProductType.DRINK);
    Product cola = new Product(7, "Cola", new BigDecimal(2), ProductType.DRINK);
    Product vodka = new Product(8, "Vodka", new BigDecimal(3), ProductType.DRINK);
    Product whiskey = new Product(9, "Whiskey", new BigDecimal(3), ProductType.DRINK);
    Product rum = new Product(10, "Rum", new BigDecimal(3), ProductType.DRINK);
    menu = new ArrayList<>(Arrays.asList(burger, pizza, fries, friesWithCheese,
        water, juice, cola, vodka, whiskey, rum));
    return menu;
  }

  public void printMenu()
  {
    System.out.println("------------------Menu---------------------");
    Iterator<Product> listIterator = menu.iterator();
    while (listIterator.hasNext()) {
      Product product = listIterator.next();
      System.out.printf(" name - %-15s - price - %5.2f  lv%n", product.getName(),
          product.getPrice());
    }
  }

  public void printListWithOrders(LinkedHashMap<String, List<String[]>> listWithOrders)
  {
    for (Entry<String, List<String[]>> entry : listWithOrders.entrySet()) {
      System.out.print(entry.getKey() + "+" + "{");
      for (String[] s : entry.getValue()) {
        System.out.print(" " + "[ " + s + "; ");
      }
      System.out.print("]}\n");
    }
  }


  public void printAllOrders()
  {
    for (Map.Entry<String, Order> e : allOrders.entrySet()) {
      System.out.print(e.getKey() + "-{" + e
          .getValue()
          .toString() + "}" + "; \n");
    }
  }

  public void prepareDrinks(ArrayBlockingQueue<Product> drinks, Bartender bartender,
      LinkedHashMap<Product, Integer> storageProducts, ArrayBlockingQueue<Product> readyOrders)
  {
    while (!drinks.isEmpty()) {
      Product p = drinks.poll();

      bartender.prepareDrink(storageProducts, p);
      readyOrders.offer(p);
    }
  }


  public void prepareFood(ArrayBlockingQueue<Dish> food, Chef chef,
      LinkedHashMap<Product, Integer> storageProducts, ArrayBlockingQueue<Dish> readyOrders)
  {
    while (!food.isEmpty()) {
      Dish p = food.poll();
      chef.cooking(storageProducts, p);
      readyOrders.offer(p);
    }
  }

  public void printDrink(ArrayBlockingQueue<Product> drinks)
  {
    Product product;
    Iterator<Product> drinksIterator = drinks.iterator();
    while (drinksIterator.hasNext()) {
      product = drinksIterator.next();
      System.out.print(product.getName() + "; ");
    }
  }

  public void printFood(ArrayBlockingQueue<Dish> food)
  {
    Dish dish;
    Iterator<Dish> foodIterator = food.iterator();
    while (foodIterator.hasNext()) {
      dish = foodIterator.next();
      System.out.print(dish.getName() + "; ");
    }

  }
}

// платено масата е свободна


