package bar_Info_Tables_Booking;

public enum IsAble
{ENABLE,
  DISABLE
}
