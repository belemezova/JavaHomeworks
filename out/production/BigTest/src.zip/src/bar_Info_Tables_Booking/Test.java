package bar_Info_Tables_Booking;

import com.codix.bar.Menu;

import java.util.Random;
import test_data.CreateTestProducts;


class Test

{

  static Random ran = new Random();

  public static void main(String[] args) throws InterruptedException
  {
    ServicesMethods method = new ServicesMethods();
    Menu menu = new Menu();
    //method.getBook().hostGuestTakenSeat();
    CreateTestProducts create = new CreateTestProducts();
    Menu menuDish = create.createDishMenu();
    Menu menuDrink = create.createDrinkMenu();
    method.puttingInOrderList("T1", "Ivo",3,method.getBook().getTaken(),
    menuDish.getDishes(),menuDrink.getDrinks());
    method.puttingInFoodListForCooker("Burger",1,menuDish.getDishes(),method.getFood());
    System.out.println(menuDish);
    Order order = new Order();
//String seatName, String staffName, int maxItemsToOrder,
//      LinkedHashMap<String, String[]> taken, LinkedHashMap<String, Order> allOrders,
//      LinkedList<String[]> orderedDishes, List<Dish> listDishes, List<Product> listDrinks
 /*   method
        .getBook()
        .vacateSeats(method
            .getBook()
            .getTaken(), method
            .getBook()
            .getAvailableSeats(), "T1");*/
    method.getProductName(method.getMenu(), 3);
    method.printMenu();

    method.getTableForDeliverPreparedFromOrder(method.getDrinks(), method.getNumberOfOrdersOnTable());
    method.printDrink(method.getDrinks());
  }
}




